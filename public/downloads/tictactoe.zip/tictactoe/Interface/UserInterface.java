package Interface;

import Logic.Board;
import Logic.Coordinate;

/**
 * Defines the contract for user interface implementations in the tic-tac-toe game.
 *
 * <p>Any class implementing this interface is responsible for handling all
 * input/output operations, including player prompts, board rendering,
 * and result display. This decouples game logic from presentation.</p>
 *
 * @author Jaydon Carter
 * @version 1.0
 * @since 1.0
 */
public interface UserInterface {
    /**
     * Prompts the user to select which player goes first.
     *
     * @return {@code 1} if the human player goes first,
     * {@code 2} if the computer goes first
     * @since 1.0
     */
    byte firstPlayer();

    /**
     * Prompts the human player to enter a valid move.
     *
     * <p>Implementations should re-prompt until a valid, unoccupied
     * coordinate is provided.</p>
     *
     * @param board the current {@link Board} state, used to validate the chosen cell
     * @return a {@link Coordinate} representing the human player's chosen move
     * @since 1.0
     */
    Coordinate getMove(Board board);

    /**
     * Renders the current state of the board to the user.
     *
     * @param board the {@link Board} to display
     * @since 1.0
     */
    void displayBoard(Board board);

    /**
     * Communicates the most recent move to the user.
     *
     * @param player the player who made the move ({@code 1} for human, {@code 2} for computer)
     * @param x      the row index of the move
     * @param y      the column index of the move
     * @implSpec For GUI implementations, displayMove can be incorporated in the displayBoard rendering
     * @since 1.0
     */
    public void displayMove(byte player, int x, int y);

    /**
     * Displays the final result of the game to the user.
     *
     * @param result {@code 1} if the human player won, {@code 2} if the computer won,
     *               or {@code 0} for a draw
     * @since 1.0
     */
    void displayResult(byte result);

    /**
     * Asks the user whether they would like to play another game.
     *
     * @return {@code true} if the user wants to play again, {@code false} otherwise
     * @since 1.0
     */
    boolean playAgain();
}