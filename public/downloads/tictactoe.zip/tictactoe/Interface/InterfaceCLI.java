package Interface;

import Logic.Board;
import Logic.Coordinate;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

/**
 * A command-line implementation of the {@link UserInterface} interface.
 *
 * <p>Handles all game I/O through standard input and output, using a
 * {@link java.util.Scanner} to read player input.</p>
 *
 * @author Jaydon Carter
 * @version 1.0
 * @since 1.0
 */
public class InterfaceCLI implements UserInterface {
    private final Scanner scanner;
    private final Map<Byte, String> INDICATOR_MAP = Map.of(
            (byte) 0, " ",
            (byte) 1, "X",
            (byte) 2, "O"
    );

    /**
     * Constructs a new {@code InterfaceCLI} instance.
     *
     * <p>Initializes the {@link java.util.Scanner} and prints the welcome banner
     * to standard output.</p>
     *
     * @since 1.0
     */
    public InterfaceCLI() {
        scanner = new Scanner(System.in);

        System.out.println("""
                  _   _       _                _        _     _        _____ _        _____            _____         \s
                 | | | |_ __ | |__   ___  __ _| |_ __ _| |__ | | ___  |_   _(_) ___  |_   _|_ _  ___  |_   _|__   ___\s
                 | | | | '_ \\| '_ \\ / _ \\/ _` | __/ _` | '_ \\| |/ _ \\   | | | |/ __|   | |/ _` |/ __|   | |/ _ \\ / _ \\
                 | |_| | | | | |_) |  __/ (_| | || (_| | |_) | |  __/   | | | | (__    | | (_| | (__    | | (_) |  __/
                  \\___/|_| |_|_.__/ \\___|\\__,_|\\__\\__,_|_.__/|_|\\___|   |_| |_|\\___|   |_|\\__,_|\\___|   |_|\\___/ \\___|
                                                                                                                      \
                """);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte firstPlayer() {
        byte first = 0;
        while (first != 1 && first != 2) {
            System.out.print("Choose who plays first (Human = 1, Computer = 2): ");
            try {
                first = scanner.nextByte();
                if (first != 1 && first != 2)
                    System.out.println("Input must be either 1 or 2");
            } catch (InputMismatchException e) {
                System.out.println("Input must be either 1 or 2");
                scanner.next();
            }
        }
        return first;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Coordinate getMove(Board board) {
        Coordinate coord = null;

        while (coord == null) {
            int x = -1;
            int y = -1;

            // Get Row
            while (x < 0 || x > 2) {
                System.out.print("\nEnter row (0-2): ");
                if (scanner.hasNextInt()) {
                    x = scanner.nextInt();
                    if (x < 0 || x > 2) System.out.println("Input must be 0, 1, or 2.");
                } else {
                    System.out.println("Invalid input. Enter a number.");
                    scanner.next();
                }
            }

            // Get Column
            while (y < 0 || y > 2) {
                System.out.print("Enter column (0-2): ");
                if (scanner.hasNextInt()) {
                    y = scanner.nextInt();
                    if (y < 0 || y > 2) System.out.println("Input must be 0, 1, or 2.");
                } else {
                    System.out.println("Invalid input. Enter a number.");
                    scanner.next();
                }
            }

            if (board.getCell(x, y) == 0) { // Cell is empty
                coord = new Coordinate(x, y);
            } else {
                System.out.println("Cell is taken. Please select a valid cell.");
            }
        }

        return coord;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void displayBoard(Board board) {
        byte[][] cells = board.getBoard();
        System.out.println("\n-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(INDICATOR_MAP.get(cells[i][j]) + " | ");
            }
            System.out.println("\n-------------");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void displayMove(byte player, int x, int y) {
        String p = (player == 1) ? "Human" : "Computer";
        System.out.println("\n" + p + " played: " + x + ", " + y);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void displayResult(byte result) {
        String winner = (result == 1) ? "Human" : (result == 2) ? "Computer" : "Draw";
        System.out.println("\nWinner: " + winner);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean playAgain() {
        String input = "";
        while (!input.equals("y") && !input.equals("n")) {
            System.out.print("Do you want to play again? (y/n): ");
            input = scanner.next().toLowerCase();
            if (!input.equals("y") && !input.equals("n")) {
                System.out.println("Input must be y or n");
            }
        }

        if (input.equals("y")) {
            return true;
        }

        scanner.close();
        return false;
    }
}