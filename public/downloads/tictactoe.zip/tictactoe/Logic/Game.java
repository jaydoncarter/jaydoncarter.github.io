package Logic;

import Interface.UserInterface;

/**
 * Manages the flow of a tic-tac-toe game session.
 *
 * <p>Coordinates interaction between the {@link Board}, the {@link Computer} AI,
 * and a {@link UserInterface} implementation. Supports replaying after a game ends.</p>
 *
 * @author Jaydon Carter
 * @version 1.0
 * @since 1.0
 */
public class Game {
    private final Computer computer;

    /**
     * Constructs a new {@code Game} instance with a fresh board and computer player.
     *
     * @since 1.0
     */
    public Game() {
        computer = new Computer();
    }

    /**
     * Starts and runs the game loop using the provided user interface.
     *
     * <p>Prompts the UI for which player goes first, then alternates turns between
     * the human and computer until a winner is found or the board is full.
     * Displays the board and move results after each turn via the UI.
     * Repeats the entire session if the player opts to play again.</p>
     *
     * @param ui the {@link UserInterface} implementation used to handle I/O
     * @throws IllegalStateException if an invalid turn value is encountered
     * @since 1.0
     */
    public void start(UserInterface ui) {
        do {
            Board board = new Board();
            byte turn = ui.firstPlayer();

            while (board.checkWinner() == 0) {
                ui.displayBoard(board);

                int x;
                int y;

                if (turn == 1) {
                    Coordinate coord = ui.getMove(board);
                    x = coord.x();
                    y = coord.y();
                    board.move(x, y, (byte) 1);
                } else if (turn == 2) {
                    Coordinate coord = computer.getMove(board);
                    x = coord.x();
                    y = coord.y();
                    board.move(x, y, (byte) 2);
                } else {
                    throw new IllegalStateException("State error: a player must move");
                }

                ui.displayMove(turn, x, y);
                turn = (byte) (3 - turn);

                if (board.isFull()) {
                    break;
                }

            }

            ui.displayResult(board.checkWinner());

        } while (ui.playAgain());

    }

}