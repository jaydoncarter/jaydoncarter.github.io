package Logic;

/**
 * Represents a 2D coordinate on the game board.
 *
 * @param x the row index (0–2)
 * @param y the column index (0–2)
 * @author Jaydon Carter
 * @version 1.0
 * @since 1.0
 */
public record Coordinate(int x, int y) {
}