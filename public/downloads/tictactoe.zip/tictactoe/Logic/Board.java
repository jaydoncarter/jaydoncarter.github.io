package Logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Represents the board state for the game.
 * <p>
 * This class handles the storage of game data and exposes methods to transition between states. It serves as the primary data model within the {@code io.github.jaydoncarter.logic} package.
 *
 * @author Jaydon Carter
 * @version 1.0
 * @implNote An untouched cell is indicated with a byte value 0, a human player cell with 1, and a computer player cell with 2.
 * @since 1.0
 */
public class Board {
    private final byte[][] board;
    private byte last;
    private int turns;

    // WIN_CONDITIONS index 0 - 3 are rows, 4-6 are columns, and 7-8 are diagonals
    final static Coordinate[][] WIN_CONDITIONS = {
            // Rows
            {new Coordinate(0, 0), new Coordinate(0, 1), new Coordinate(0, 2)},
            {new Coordinate(1, 0), new Coordinate(1, 1), new Coordinate(1, 2)},
            {new Coordinate(2, 0), new Coordinate(2, 1), new Coordinate(2, 2)},
            // Columns
            {new Coordinate(0, 0), new Coordinate(1, 0), new Coordinate(2, 0)},
            {new Coordinate(0, 1), new Coordinate(1, 1), new Coordinate(2, 1)},
            {new Coordinate(0, 2), new Coordinate(1, 2), new Coordinate(2, 2)},
            // Diagonals
            {new Coordinate(0, 0), new Coordinate(1, 1), new Coordinate(2, 2)},
            {new Coordinate(0, 2), new Coordinate(1, 1), new Coordinate(2, 0)}
    };

    /**
     * Constructor for the Board class
     *
     * <p>This method creates and new instance of Board</p>
     *
     * @see Arrays#fill(byte[] a, byte val)
     * @since 1.0
     */
    public Board() {
        // byte is the smallest Java data type that can represent at least 3 states
        board = new byte[3][3];

        for (int i = 0; i < 3; i++) {
            Arrays.fill(board[i], (byte) 0);
        }

        last = 0;
        turns = 0;
    }

    /**
     * Copy constructor for the Board class.
     *
     * <p>Creates a deep copy of the provided {@code Board} instance,
     * preserving all cell values, the last player to move, and turn count.</p>
     *
     * @param original the {@code Board} instance to copy
     * @since 1.0
     */
    public Board(Board original) {
        this.board = new byte[3][3];
        for (int i = 0; i < 3; i++) {
            this.board[i] = Arrays.copyOf(original.board[i], 3);
        }
        last = original.last;
        turns = original.turns;
    }

    /**
     * Modifies and validates game state.
     *
     * <p>This method attempts to modify game state by updating a cell.</p>
     *
     * @param x      the x coordinate of the cell to update
     * @param y      the y coordinate of the cell to update
     * @param player the player value to assign to the cell
     * @throws IllegalArgumentException if coordinate is invalid
     * @throws IllegalArgumentException if player is invalid
     * @throws IllegalArgumentException if cell is occupied
     * @throws IllegalStateException    if player moves twice consecutively
     * @since 1.0
     */
    public void move(int x, int y, byte player) {
        if (isFull()) {
            throw new IllegalStateException("Board is full");
        }

        // Validate location
        validateCoordinate(x, y);

        // Validate player
        if (player != 1 && player != 2) {
            throw new IllegalArgumentException("Invalid player " + player);
        }

        // Validate cell state
        if (board[x][y] != 0) {
            throw new IllegalArgumentException("Cannot set player to cell (" + x + ", " + y + "): cell is not empty");
        }

        // Validate play state
        if (last == player) {
            throw new IllegalStateException("State error: player cannot move twice consecutively");
        }

        board[x][y] = player;
        last = player;
        turns++;
    }

    /**
     * Checks whether either player has won the game.
     *
     * <p>Evaluates all possible win conditions (rows, columns, and diagonals).
     * Returns early with {@code 0} if fewer than 5 turns have been played,
     * as a win is impossible before then.</p>
     *
     * @return {@code 1} if the human player has won, {@code 2} if the computer
     * has won, or {@code 0} if there is no winner yet
     * @since 1.0
     */
    public byte checkWinner() {
        if (turns < 5) {
            return 0; // Not enough turns
        }

        for (Coordinate[] condition : WIN_CONDITIONS) {
            byte a = board[condition[0].x()][condition[0].y()];
            byte b = board[condition[1].x()][condition[1].y()];
            byte c = board[condition[2].x()][condition[2].y()];
            if (a == b && b == c) {
                return a;
            }
        }

        return 0; // No winner
    }

    /**
     * Checks whether the board is fully occupied.
     *
     * @return {@code true} if all 9 cells have been played, {@code false} otherwise
     * @since 1.0
     */
    public boolean isFull() {
        return turns == 9;
    }

    /**
     * Returns the value of a specific cell on the board.
     *
     * @param x the row index of the cell (0–2)
     * @param y the column index of the cell (0–2)
     * @return {@code 0} if the cell is empty, {@code 1} if occupied by the human
     * player, or {@code 2} if occupied by the computer player
     * @throws IllegalArgumentException if the coordinate is out of bounds
     * @since 1.0
     */
    public byte getCell(int x, int y) {
        validateCoordinate(x, y);
        return board[x][y];
    }

    /**
     * Returns a deep copy of the underlying board array.
     *
     * <p>Modifications to the returned array will not affect the internal board state.</p>
     *
     * @return a 3x3 {@code byte[][]} copy of the current board
     * @since 1.0
     */
    public byte[][] getBoard() {
        byte[][] copy = new byte[3][3];
        for (int i = 0; i < 3; i++) {
            copy[i] = Arrays.copyOf(board[i], 3);
        }
        return copy;
    }

    /**
     * Returns a list of all currently unoccupied cells on the board.
     *
     * @return a {@link java.util.List} of {@link Coordinate} objects representing
     * every cell whose value is {@code 0}
     * @since 1.0
     */
    public List<Coordinate> getAvailableMoves() {
        List<Coordinate> moves = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (getCell(i, j) == 0) {
                    moves.add(new Coordinate(i, j));
                }
            }
        }
        return moves;
    }

    /**
     * Returns a string representation of the board as a 2D array.
     *
     * @return a {@code String} in the format produced by {@link java.util.Arrays#deepToString(Object[])}
     * @see Arrays#deepToString(Object[])
     * @since 1.0
     */
    @Override
    public String toString() {
        return Arrays.deepToString(board);
    }

    /**
     * Checks equality between this board and another object.
     *
     * <p>Two boards are considered equal if all corresponding cells contain
     * the same values. Turn count and last-player state are not considered.</p>
     *
     * @param other the object to compare against
     * @return {@code true} if {@code other} is a {@code Board} with identical
     * cell contents, {@code false} otherwise
     * @since 1.0
     */
    @Override
    public boolean equals(Object other) {
        // Identity check
        if (this == other) {
            return true;
        }

        // Null check and type check
        if (!(other instanceof Board boardOther)) {
            return false;
        }

        // Content check
        byte[][] otherBoard = boardOther.getBoard();
        for (int i = 0; i < 3; i++) {
            if (!Arrays.equals(board[i], otherBoard[i])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Validates that the given coordinate is within the bounds of the board.
     *
     * @param x the row index to validate
     * @param y the column index to validate
     * @throws IllegalArgumentException if either index is less than {@code 0}
     *                                  or greater than {@code 2}
     * @since 1.0
     */
    private void validateCoordinate(int x, int y) {
        if (x < 0 || y < 0 || x >= 3 || y >= 3) {
            throw new IllegalArgumentException("Cannot access cell (" + x + ", " + y + "): coordinate out of bounds");
        }
    }
}