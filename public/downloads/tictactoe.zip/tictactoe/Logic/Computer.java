package Logic;

import java.util.List;

/**
 * Represents the computer player in a tic-tac-toe game.
 *
 * <p>Uses the Minimax algorithm to determine the optimal move,
 * making the computer player unbeatable under perfect play.</p>
 *
 * @author Jaydon Carter
 * @version 1.0
 * @since 1.0
 */
public class Computer {
    /**
     * Determines the best move for the computer player on the given board.
     *
     * <p>Evaluates all available moves using the {@link #minimax} algorithm
     * and selects the one with the highest score.</p>
     *
     * @param board the current {@link Board} state
     * @return a {@link Coordinate} representing the optimal cell for the computer to play
     * @since 1.0
     */
    public Coordinate getMove(Board board) {
        int bestScore = Integer.MIN_VALUE;
        int bestRow = -1;
        int bestCol = -1;

        List<Coordinate> moves = board.getAvailableMoves();

        for (Coordinate coord : moves) {
            Board testBoard = new Board(board);

            testBoard.move(coord.x(), coord.y(), (byte) 2);

            int score = minimax(testBoard, false);

            if (score > bestScore) {
                bestScore = score;
                bestRow = coord.x();
                bestCol = coord.y();
            }
        }

        return new Coordinate(bestRow, bestCol);
    }

    /**
     * Recursively evaluates board states using the Minimax algorithm.
     *
     * <p>Assigns a score of {@code 1} for a computer win, {@code -1} for a human win,
     * and {@code 0} for a draw. When maximizing, selects the move with the highest
     * score; when minimizing, selects the move with the lowest score.</p>
     *
     * @param board        the {@link Board} state to evaluate
     * @param isMaximizing {@code true} if it is the computer's turn (maximizing player),
     *                     {@code false} if it is the human's turn (minimizing player)
     * @return an integer score representing the outcome of the evaluated board state
     * @since 1.0
     */
    private int minimax(Board board, boolean isMaximizing) {
        byte winner = board.checkWinner();
        if (winner == 2) {
            return 1;
        }


        if (winner == 1) {
            return -1;
        }

        if (board.isFull()) {
            return 0;
        }

        List<Coordinate> moves = board.getAvailableMoves();

        if (isMaximizing) {
            int bestScore = Integer.MIN_VALUE;

            for (Coordinate coord : moves) {
                Board testBoard = new Board(board);
                testBoard.move(coord.x(), coord.y(), (byte) 2);
                int score = minimax(testBoard, false);
                bestScore = Math.max(score, bestScore);
            }

            return bestScore;

        } else {

            int bestScore = Integer.MAX_VALUE;

            for (Coordinate coord : moves) {
                Board testBoard = new Board(board);
                testBoard.move(coord.x(), coord.y(), (byte) 1);
                int score = minimax(testBoard, true);
                bestScore = Math.min(score, bestScore);
            }

            return bestScore;
        }
    }
}