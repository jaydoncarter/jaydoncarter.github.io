import Interface.InterfaceCLI;
import Logic.Game;

/**
 * Entry point for the tic-tac-toe application.
 *
 * <p>Creates a new {@link Logic.Game} instance and starts it with a
 * command-line interface via {@link Interface.InterfaceCLI}.</p>
 *
 * @author Jaydon Carter
 * @since 1.0
 */
void main() {
  Game game = new Game();
  game.start(new InterfaceCLI());
}