# Unbeatable Tic-Tac-Toe with Minimax Algorithm

A flexible Tic-Tac-Toe game in Java featuring an unbeatable AI opponent powered by the Minimax algorithm. Built as an independent learning project to explore adversarial search and clean software architecture. This is still a work in progress, so expect more updates soon!

🔗 **Source Code**: [jaydoncarter.github.io/projects.html](https://jaydoncarter.github.io/projects.html)

---

## ⚙️ How It Works

The `Computer` class uses **Minimax**, a recursive adversarial search algorithm that explores every possible future game state from the current board position.

Each terminal state is assigned a score:
- `+1` — computer wins
- `-1` — human wins
- `0` — draw

The computer (maximizing player) always selects the move leading to the highest score; the human (minimizing player) is assumed to always select the move leading to the lowest. Because the algorithm explores the full game tree exhaustively, the computer will never make a suboptimal move.

---

## 🛠 Technologies Used

- Java 25
- JUnit
- IntelliJ IDEA

---

## 🚀 Getting Setup

To run the CLI program locally:

```bash
# Ensure Java 8+ is installed

git clone https://github.com/jaydoncarter/tictactoe.git
cd tictactoe

javac -d out $(find . -name "*.java")
java -cp out Main
```

---

## 📂 Package Structure

```markdown
/
├── Main.java
├── Logic
|   ├── Game.java
│   ├── Board.java
│   ├── Computer.java
│   └── Coordinate.java
│
└── Interface
│   ├── InterfaceCLI.java
│   └── UserInterface.java
```
---

## Improvements Coming Soon

- A Swing GUI implementing `UserInterface`
- Alpha-beta pruning to reduce the number of nodes evaluated by Minimax
- Machine-specific executable for ease of use

---

## 📬 Contact

Feel free to reach out through any of the methods on my [website](https://jaydoncarter.github.io/contact.html) or directly at [jaydoncarter898@gmail.com](jaydoncarter898@gmail.com).

---
